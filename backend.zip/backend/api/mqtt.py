from backend import app, socketio, mqtt
from backend.api.thread import *
from flask import json
import json as std_json  # 표준 라이브러리 json (JSONDecodeError용)
from backend.db.table.table_band import *
from backend.db.service.query import *
from backend.api.crawling import *
from threading import Lock
from logger_config import app_logger
from datetime import timedelta
from sqlalchemy import text
from collections import defaultdict
from functools import lru_cache
import time
import sys
import re
sys.setrecursionlimit(10000)  # 재귀 제한 증가

# 캐시 저장을 위한 전역 변수 추가
last_event_cache = defaultdict(dict)
EVENT_COOLDOWN = 0.5  # 중복 처리 방지 시간 (초)

# Band 정보 메모리 캐시 (bid -> (name, alias) 매핑)
band_info_cache = {}
band_cache_lock = Lock()

mqtt_thread = None
gw_thread = None
event_thread = None

num = 0
thread_lock = Lock()


def get_band_display_name(bid):
    """Band의 표시 이름을 빠르게 가져오기 (캐시 사용)"""
    with band_cache_lock:
        # 캐시에 있으면 반환
        if bid in band_info_cache:
            cached = band_info_cache[bid]
            return cached.get('display_name', bid)

    # 캐시 미스 - DB에서 조회
    try:
        dev = db.session.query(Bands).filter_by(bid=bid).first()
        if dev:
            display_name = dev.name
            if not display_name or display_name.lower() in ['init', 'none', '']:
                display_name = dev.alias if dev.alias else dev.bid

            # 캐시에 저장
            with band_cache_lock:
                band_info_cache[bid] = {
                    'id': dev.id,
                    'name': dev.name,
                    'alias': dev.alias,
                    'display_name': display_name
                }
            return display_name
        else:
            return bid
    except Exception as e:
        app_logger.error(f"Error fetching band info for {bid}: {e}")
        return bid


def update_band_cache(bid, name=None, alias=None, band_id=None):
    """Band 캐시 업데이트 (sync 토픽에서 호출)"""
    with band_cache_lock:
        if bid not in band_info_cache:
            band_info_cache[bid] = {}

        cache_entry = band_info_cache[bid]
        if band_id is not None:
            cache_entry['id'] = band_id
        if name is not None:
            cache_entry['name'] = name
        if alias is not None:
            cache_entry['alias'] = alias

        # display_name 계산
        display_name = cache_entry.get('name', '')
        if not display_name or display_name.lower() in ['init', 'none', '']:
            display_name = cache_entry.get('alias', '') or bid
        cache_entry['display_name'] = display_name


# MQTT 연결 핸들러
@mqtt.on_connect()
def handle_connect(client, userdata, flags, rc):
    if rc == 0:
        app_logger.info("Successfully connected to MQTT broker")
        print("*** MQTT CONNECTED ***")
        mqtt.subscribe('/DT/eHG4/naas/post/sync')
        mqtt.subscribe('/DT/eHG4/naas/post/async')
        mqtt.subscribe('/DT/eHG4/naas/WEATHER/GET')
        mqtt.subscribe('/DT/eHG4/naas/INFO/GET')
        mqtt.subscribe('/DT/eHG4/naas/Status/Band_Events_Data')
        mqtt.subscribe('/DT/eHG4/naas/GPS/Location')
        app_logger.info("MQTT subscriptions completed")
        print("*** MQTT SUBSCRIPTIONS COMPLETED ***")
    else:
        app_logger.error(f"Failed to connect to MQTT broker, return code {rc}")
        print(f"*** MQTT CONNECTION FAILED: {rc} ***")


@mqtt.on_log()
def handle_logging(client, userdata, level, buf):
    app_logger.debug(f"MQTT: {buf}")


def mqttPublish(topic, message):
  mqtt.publish(topic, message)


def getAltitude(pressure, airpressure):  # 기압 - 높이 계산 Dtriple
  try:
      # ***분모 자리에 해면기압 정보 넣을 것!! (ex. 1018) // Dtriple
      p = (pressure / (airpressure * 100))
      b = 1 / 5.255
      alt = 44330 * (1 - p**b)

      return round(alt, 2)
  except:
      pass

# New CHU MQTT Message Parsing
def handle_gps_data(mqtt_data, extAddress):
    app_logger.debug(f"Processing GPS data: {mqtt_data}")
    try:
        # extAddress는 이미 high 값 (밴드 ID)
        mqtt_data['extAddress']['high'] = extAddress
        # Find the corresponding band
        band = db.session.query(Bands).filter_by(bid=extAddress).first()
        
        if band is None:
            app_logger.warning(f"Band not found for extAddress: {extAddress}")
            return
        
        timestamp = datetime.datetime.now(timezone('Asia/Seoul'))
        
        gps_info = mqtt_data['data'].split(',')
        
        # GPS 데이터 형식에 따라 다르게 처리
        if len(gps_info) == 4:
            latitude, longitude, altitude, speed = gps_info
            gps_data = {
                'bid': extAddress,
                'latitude': float(latitude),
                'longitude': float(longitude),
                'altitude': float(altitude),
                'speed': float(speed),
                'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')
            }
        elif len(gps_info) == 5:
            latitude, longitude, altitude, speed, course = gps_info
            gps_data = {
                'bid': extAddress,
                'latitude': float(latitude),
                'longitude': float(longitude),
                'altitude': float(altitude),
                'speed': float(speed),
                'course': float(course),
                'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')
            }
        elif len(gps_info) == 6:
            latitude, longitude, altitude, speed, course, sats = gps_info
            gps_data = {
                'bid': extAddress,
                'latitude': float(latitude),
                'longitude': float(longitude),
                'altitude': float(altitude),
                'speed': float(speed),
                'course': float(course),
                'satellites': int(float(sats)),
                'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S')
            }
        else:
            app_logger.error(f"Invalid GPS data format: {mqtt_data['data']}")
            return
          
        try:
            # gps_data 확인
            print(f"GPS 데이터 확인: {gps_data}")
            
            # band 조회 결과 확인
            band = db.session.query(Bands).filter_by(bid=gps_data['bid']).first()
            print(f"조회된 band: {band.bid if band else 'Not Found'}")
            
            if band:
                print(f"업데이트 전 위치: lat={band.latitude}, lng={band.longitude}")
                band.latitude = gps_data['latitude']
                band.longitude = gps_data['longitude']
                db.session.commit()
                print(f"업데이트 후 위치: lat={band.latitude}, lng={band.longitude}")
            else:
                print(f"해당 bid를 가진 band를 찾을 수 없음: {gps_data['bid']}")
                
        except Exception as e:
            print(f"GPS 데이터 DB 업데이트 중 에러 발생: {e}")
        
        # Emit the GPS data to the frontend
        socketio.emit('ehg4_gps', gps_data, namespace='/admin')
        app_logger.debug(f"GPS Data : {gps_data}")
        app_logger.info(f"Successfully processed and emitted GPS data for band: {extAddress}")
        
    except Exception as e:
        app_logger.error(f"Unexpected error processing eHG4 GPS data: {str(e)}", exc_info=True)

def handle_ehg4_data(data, b_id):
  
  app_logger.debug(f"Processing GPS data: {b_id}")
  
  try:
    band = db.session.query(Bands).filter_by(bid=b_id).first()
    
    if band is None:
      app_logger.info(f"An unregistered band: {b_id}. Attempting to insert into database.")
      insert_success = insertBandData(b_id)
      if not insert_success:
        app_logger.error(f"Failed to insert new band: {b_id}")
        return  # 밴드 삽입 실패 시 함수 종료
      
      band = selectBandBid(b_id)
      if band is None:
        app_logger.error(f"Band insertion succeeded but unable to retrieve: {data['bid']}")
        return  # 밴드 조회 실패 시 함수 종료
      
    altitude = getAltitude(data['pres'])
    data['bid'] = b_id
    
    sensor_data = SensorData(
      FK_bid=band.id,
      hr=data['hr'],
      spo2=data['spo2'],
      motionFlag=data['motionFlag'],
      scdState=data['scdState'],
      activity=data['activity'],
      walk_steps=data['walk_steps'],
      run_steps=data['run_steps'],
      temperature=data['temperature'],
      altitude=altitude,
      battery_level=data['battery_level'],
      rssi_lte=data['rssi_lte']
    )
    # print(sensor_data)
      
    db.session.add(sensor_data)
    db.session.commit()
    app_logger.info(f"Successfully saved sensor data to database for band: {data['bid']}")
    
    # 실시간 데이터 전송
    socketio.emit('ehg4_data', data, namespace='/admin')
    app_logger.info(f"Successfully emitted real-time data for band: {data['bid']}")
      
  except SQLAlchemyError as e:
    db.session.rollback()
    app_logger.error(f"Database error while saving sensor data for band {data['bid']}: {str(e)}")
  except Exception as e:
    app_logger.error(f"Unexpected error processing eHG4 data for band {data['bid']}: {str(e)}")



def handle_sync_data(mqtt_data, extAddress):
  app_logger.info(f"handle_sync_data called: extAddress={extAddress}")
  print(f"handle_sync_data called: extAddress={extAddress}")

  dev = db.session.query(Bands).filter_by(bid=extAddress).first()

  if dev is not None:
    app_logger.info(f"Band found: {dev.bid} ({dev.name})")
    print(f"Band found: {dev.bid} ({dev.name})")

    # Band 캐시 업데이트 (async 토픽에서 빠르게 조회하기 위해)
    update_band_cache(dev.bid, name=dev.name, alias=dev.alias, band_id=dev.id)

    try:
      # 밴드 연결 상태 업데이트
      dev.connect_state = 1  # 1: connected
      dev.connect_time = datetime.datetime.now(timezone('Asia/Seoul'))
      db.session.commit()

      # pid가 있는 경우에만 게이트웨이 처리 (optional)
      gatewayDev = None
      sensorDev = None
      if 'pid' in mqtt_data:
        gatewayDev = db.session.query(Gateways.airpressure).\
          filter(Gateways.pid == mqtt_data['pid']).first()

        if gatewayDev is not None:
          sensorDev = db.session.query(WalkRunCount).\
            filter(WalkRunCount.FK_bid == dev.id).\
            filter(func.date(WalkRunCount.datetime) == func.date(datetime.datetime.now(timezone('Asia/Seoul')))).first()
          db.session.flush()

      mqtt_data['extAddress']['high'] = extAddress
      bandData = mqtt_data['bandData']
      data = SensorData()
      data.FK_bid = dev.id
      data.start_byte = bandData.get('start_byte', 0)
      data.sample_count = bandData.get('sample_count', 0)
      data.fall_detect = bandData.get('fall_detect', 0)
      data.battery_level = bandData.get('battery_level', 0)
      data.hrConfidence = bandData.get('hrConfidence', 0)
      data.spo2Confidence = bandData.get('spo2Confidence', 0)
      data.hr = bandData.get('hr', 0)
      data.spo2 = bandData.get('spo2', 0)
      data.motionFlag = bandData.get('motionFlag', 0)
      data.scdState = bandData.get('scdState', 0)
      data.activity = bandData.get('activity', 0)

      temp_walk_steps = bandData.get('walk_steps', 0)
      if sensorDev is not None:
        if sensorDev.walk_steps > bandData.get('walk_steps', 0):
          tempwalk = bandData.get('walk_steps', 0) - \
            sensorDev.temp_walk_steps

          if tempwalk > 0:
            mqtt_data['bandData']['walk_steps'] = sensorDev.walk_steps + tempwalk

          elif tempwalk < 0:
            mqtt_data['bandData']['walk_steps'] = sensorDev.walk_steps + \
              bandData.get('walk_steps', 0)

          else:
            mqtt_data['bandData']['walk_steps'] = sensorDev.walk_steps

        elif sensorDev.walk_steps == bandData.get('walk_steps', 0):
          mqtt_data['bandData']['walk_steps'] = sensorDev.walk_steps
      data.walk_steps = mqtt_data['bandData'].get('walk_steps', 0)
      data.temp_walk_steps = temp_walk_steps

      walkRunCount = WalkRunCount()
      walkRunCount.FK_bid = dev.id
      walkRunCount.walk_steps = mqtt_data['bandData'].get('walk_steps', 0)
      walkRunCount.temp_walk_steps = temp_walk_steps

      temp_run_steps = bandData.get('run_steps', 0)
      if sensorDev is not None:
        if sensorDev.run_steps > bandData.get('run_steps', 0):
          tempwalk = bandData.get('run_steps', 0) - \
              sensorDev.temp_run_steps
          if tempwalk > 0:
              mqtt_data['bandData']['run_steps'] = sensorDev.run_steps + tempwalk

          elif tempwalk < 0:
            mqtt_data['bandData']['run_steps'] = sensorDev.run_steps + \
              bandData.get('run_steps', 0)

          else:
            mqtt_data['bandData']['run_steps'] = sensorDev.run_steps

        elif sensorDev.run_steps == bandData.get('run_steps', 0):
          mqtt_data['bandData']['run_steps'] = sensorDev.run_steps

      data.run_steps = mqtt_data['bandData'].get('run_steps', 0)
      data.temp_run_steps = temp_run_steps

      walkRunCount.run_steps = mqtt_data['bandData'].get('run_steps', 0)
      walkRunCount.temp_run_steps = temp_run_steps
      walkRunCount.datetime = datetime.datetime.now(
          timezone('Asia/Seoul'))
      sensorDev = db.session.query(WalkRunCount).\
          filter(WalkRunCount.FK_bid == dev.id).first()
      if sensorDev is not None:
        db.session.query(WalkRunCount).\
          filter(WalkRunCount.FK_bid == dev.id).\
          update(dict(walk_steps=walkRunCount.walk_steps,
                      temp_walk_steps=walkRunCount.temp_walk_steps,
                      run_steps=walkRunCount.run_steps,
                      temp_run_steps=walkRunCount.temp_run_steps,
                      datetime=walkRunCount.datetime))
        db.session.commit()
        db.session.flush()
      else:
        db.session.add(walkRunCount)
        db.session.commit()
        db.session.flush()
      data.x = bandData.get('x', 0)
      data.y = bandData.get('y', 0)
      data.z = bandData.get('z', 0)
      data.t = bandData.get('t', 0)
      data.h = bandData.get('h', 0)
      data.rssi = mqtt_data.get('rssi', 0)
      data.datetime = datetime.datetime.now(timezone('Asia/Seoul'))
      db.session.add(data)
      db.session.commit()
      db.session.flush()
      
      # Emit the sync data to the frontend
      app_logger.info(f"Emitting sync data: {mqtt_data} to namespace '/admin'")
      socketio.emit('efwbsync', mqtt_data, namespace='/admin')
      # app_logger.debug(f"sync data = {mqtt_data}")
      app_logger.info(f"Successfully processed and emitted sync data for band: {extAddress}")

      # 배터리 부족 알림 자동 생성 (40% 이하)
      if bandData.get('battery_level', 100) <= 40:
        # 의미있는 이름 선택: name이 없거나 'init'이면 alias 사용, 둘 다 없으면 bid 사용
        display_name = dev.name
        if not display_name or display_name.lower() in ['init', 'none', '']:
          display_name = dev.alias if dev.alias else dev.bid

        battery_event = {
          "type": "battery",
          "value": str(bandData.get('battery_level', 0)),
          "bid": dev.bid,
          "name": display_name
        }
        socketio.emit('efwbasync', battery_event, namespace='/admin')
        app_logger.info(f"Battery low alert sent for band {dev.bid}: {bandData.get('battery_level')}%")

      # MQTT 날씨 정보 발행 (optional)
      try:
        if WeatherState.tempor and WeatherState.humidity:
          topic = "/DT/test_eHG4/Status/BandSet"
          temperature = int(float(WeatherState.tempor.replace("°", "")) * 100)
          humidity = int(WeatherState.humidity.replace("%", ""))
          message = f"#XMQTTSUBMSG : {extAddress},{temperature},{humidity}"
          mqtt.publish(topic, message)
          app_logger.info(f"MQTT message sent to {topic}: {message}")
      except Exception as e:
        app_logger.error(f"Failed to publish MQTT weather message: {e}")

    except Exception as e:
      db.session.rollback()
      app_logger.error(f"Error up dating band connection status: {str(e)}")
      print("****** error ********")
      print(e)
    finally:
        db.session.remove()
  else:
    app_logger.warning(f"Band not found: {extAddress}, attempting to insert")
    print(f"Band not found: {extAddress}, attempting to insert")
    insertBandData(extAddress)
    band = selectBandBid(extAddress)
    # pid가 있는 경우에만 게이트웨이 연결 (optional)
    if 'pid' in mqtt_data:
      gw = selectGatewayPid(mqtt_data['pid'])
      if band is not None and gw is not None:
        insertGatewaysBands(gw.id, band.id)
        insertUsersBands(1, band.id)

def check_disconnected_bands():
    with app.app_context():
        try:
            connected_bands = db.session.query(Bands).filter_by(connect_state=1).all()
            current_time = datetime.datetime.now(timezone('Asia/Seoul'))
            
            for band in connected_bands:
                # connect_time에 timezone 정보 추가
                if band.connect_time:
                    band_connect_time = band.connect_time
                    if band_connect_time.tzinfo is None:
                        band_connect_time = timezone('Asia/Seoul').localize(band_connect_time)
                    
                    if (current_time - band_connect_time) > timedelta(minutes=1):
                        band.connect_state = 0
                        band.disconnect_time = current_time

                        # 의미있는 이름 선택: name이 없거나 'init'이면 alias 사용, 둘 다 없으면 bid 사용
                        display_name = band.name
                        if not display_name or display_name.lower() in ['init', 'none', '']:
                            display_name = band.alias if band.alias else band.bid

                        disconnect_event = {
                            "bid": band.bid,
                            "name": display_name,
                            "disconnect_time": band.disconnect_time.strftime("%Y-%m-%d %H:%M:%S")
                        }
                        socketio.emit('band_disconnect', disconnect_event, namespace='/admin')
                
            db.session.commit()
            app_logger.info("Successfully checked and updated disconnected bands")
            
        except Exception as e:
            db.session.rollback()
            app_logger.error(f"Error checking disconnected bands: {str(e)}")

# 백그라운드 스케줄러 설정
def start_disconnect_checker():
    """5분마다 연결 해제 상태를 체크하는 스케줄러 시작"""
    while True:
        check_disconnected_bands()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
        socketio.sleep(150)  # 2분 30초
    
def handle_gateway_state(panid):
  print("handle_gateway_state", panid)
  try:
    dev = selectGatewayPid(panid['panid'])
    if dev is not None:
      if dev.ip != panid['ip']:                                                                                                                                                                                                                                                                                               
        updateGatewaysIP(dev.id, panid['ip'])
      if dev.connect_state == 0:
        updateGatewaysConnect(dev.id, True)
      else:
        updateGatewaysConnectCheck(dev.id)
    else:
      insertGateway(panid)
      dev = selectGatewayPid(panid['panid'])
      d = datetime.datetime.now(timezone('Asia/Seoul'))
      urldate = str(d.year)+"."+str(d.month) + \
        "."+str(d.day)+"."+str(d.hour)
      trtemp, atemp = getAirpressure(urldate)
      if trtemp != 0:
        updateGatewaysAirpressure(dev.id, searchAirpressure(trtemp, atemp, dev.location))
      socketio.emit('gateway_connect', panid, namespace='/admin')
  except:
      pass

@mqtt.on_message()
def handle_mqtt_message(client, userdata, message):
  try:
    # 메시지 수신 로그
    app_logger.info(f"MQTT Message Received - Topic: {message.topic}, Payload size: {len(message.payload)} bytes")
    print(f"MQTT Message Received - Topic: {message.topic}")

    global mqtt_thread, gw_thread, event_thread, num, thread_lock

    topic = message.topic
    payload = message.payload.decode()

    # ===== ASYNC 토픽 최우선 처리 =====
    if topic == '/DT/eHG4/naas/post/async':
        # 최우선 처리 - 로그 최소화
        try:
            # 빈 payload 체크
            if not payload or not payload.strip().startswith('{'):
                return

            event_data = json.loads(payload)

            extAddress = int(
                    format(event_data['extAddress']['high'], 'x') +
                    format(event_data['extAddress']['low'], 'x'), 16
            )

            # 중복 체크
            cache_key = f"{extAddress}_{event_data['type']}_{event_data['value']}"
            current_time = time.time()

            if cache_key in last_event_cache:
                if current_time - last_event_cache[cache_key] < EVENT_COOLDOWN:
                    return

            last_event_cache[cache_key] = current_time

            # 캐시에서 이름 빠르게 조회
            display_name = get_band_display_name(extAddress)

            # 즉시 전송 (이름 포함)
            event_socket = {
                "type": event_data['type'],
                "value": event_data['value'],
                "bid": extAddress,
                "name": display_name
            }
            socketio.emit('efwbasync', event_socket, namespace='/admin')
            app_logger.info(f"Async event: band {extAddress} type={event_data['type']} value={event_data['value']}")

        except std_json.JSONDecodeError:
            pass  # Non-JSON 메시지 무시
        except Exception as e:
            app_logger.error(f"Async error: {str(e)}")

    elif topic == '/DT/eHG4/naas/post/sync':
        app_logger.info("Processing /DT/eHG4/naas/post/sync message")
        print("Processing sync message")

        try:
            # 줄바꿈 및 제어 문자 제거
            payload_str = payload.replace('\n', '').replace('\r', '').replace('\t', '')
            app_logger.debug(f"Decoded payload: {payload_str[:200]}...")

            mqtt_data = json.loads(payload_str)
            app_logger.info(f"JSON parsed successfully")

            extAddress = int(
                    format(mqtt_data['extAddress']['high'], 'x') +
                    format(mqtt_data['extAddress']['low'], 'x'), 16
            )
            app_logger.info(f"ExtAddress (Band ID): {extAddress}")
            print(f"ExtAddress (Band ID): {extAddress}")

            # 직접 호출 (가장 확실한 방법)
            app_logger.info(f"Calling handle_sync_data directly")
            handle_sync_data(mqtt_data, extAddress)
            app_logger.info(f"handle_sync_data completed")

        except std_json.JSONDecodeError as je:
            app_logger.error(f"JSON parsing error: {str(je)}")
            app_logger.error(f"Problematic payload: {payload[:500]}")
            print(f"JSON parsing error: {je}")
        except Exception as e:
            app_logger.error(f"Error processing sync message: {str(e)}", exc_info=True)
            print(f"Error: {e}")
                
    elif topic == '/DT/eHG4/naas/GPS/Location':
        def job():
            fixed_payload = re.sub(
                r'("data"\s*:\s*".*?,\d+\.\d+,)"(20\d{2}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})""',
                r'\1\2"', payload
            )
            mqtt_data = json.loads(fixed_payload)
            extAddress = int(
                format(mqtt_data['extAddress']['high'], 'x') +
                format(mqtt_data['extAddress']['low'], 'x'), 16
            )
            handle_gps_data(mqtt_data=mqtt_data, extAddress=extAddress)

        # enqueue 함수가 정의되어 있다면 사용, 없으면 직접 호출
        try:
            enqueue(1, job)
        except NameError:
            job()

  except Exception as e:
    app_logger.error(f"Error in MQTT message handler: {str(e)}", exc_info=True)
