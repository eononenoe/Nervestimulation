# -*- coding: utf-8 -*-
from pytz import timezone
import datetime
from backend.db.database import DBManager
print("module [backend_model.table_stats.py] loaded")

db = DBManager.db


class Departments(db.Model):
    """부서/팀 관리"""
    __tablename__ = 'departments'

    id = db.Column('id', db.Integer, primary_key=True)
    name = db.Column('name', db.String(100), nullable=False, comment='부서명')
    parent_id = db.Column('parent_id', db.Integer,
                          db.ForeignKey('departments.id', ondelete='CASCADE'),
                          nullable=True, comment='상위 부서 ID')
    parent = db.relationship('Departments', remote_side=[id], backref='children')

    manager_id = db.Column('manager_id', db.Integer, nullable=True, comment='부서장 ID')
    location = db.Column('location', db.String(100), comment='위치')
    created = db.Column('created', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='생성시간')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "name": self.name,
            "parent_id": self.parent_id,
            "manager_id": self.manager_id,
            "location": self.location,
            "created": self.created.isoformat() if self.created else None
        }
        return resultJSON


class BandsDepartments(db.Model):
    """근로자-부서 매핑"""
    __tablename__ = 'bands_departments'

    id = db.Column('id', db.Integer, primary_key=True)
    FK_bid = db.Column('FK_bid', db.Integer, nullable=False, comment='밴드 ID')
    FK_dept_id = db.Column('FK_dept_id', db.Integer,
                           db.ForeignKey('departments.id', ondelete='CASCADE'),
                           nullable=False, comment='부서 ID')
    department = db.relationship('Departments', backref='bands')

    assigned_date = db.Column('assigned_date', db.DateTime,
                             default=datetime.datetime.now(timezone('Asia/Seoul')),
                             comment='배정일')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "FK_bid": self.FK_bid,
            "FK_dept_id": self.FK_dept_id,
            "assigned_date": self.assigned_date.isoformat() if self.assigned_date else None
        }
        return resultJSON


class DailyStatistics(db.Model):
    """일별 건강 통계"""
    __tablename__ = 'daily_statistics'

    id = db.Column('id', db.Integer, primary_key=True)
    date = db.Column('date', db.Date, nullable=False, comment='날짜')
    FK_bid = db.Column('FK_bid', db.Integer, nullable=False, comment='밴드 ID')

    avg_hr = db.Column('avg_hr', db.Numeric(5, 2), comment='평균 심박수')
    min_hr = db.Column('min_hr', db.Integer, comment='최소 심박수')
    max_hr = db.Column('max_hr', db.Integer, comment='최대 심박수')

    avg_spo2 = db.Column('avg_spo2', db.Numeric(5, 2), comment='평균 SpO2')
    min_spo2 = db.Column('min_spo2', db.Integer, comment='최소 SpO2')

    total_steps = db.Column('total_steps', db.Integer, default=0, comment='총 걸음 수')
    total_kcal = db.Column('total_kcal', db.Numeric(10, 2), default=0, comment='총 소모 칼로리')

    work_hours = db.Column('work_hours', db.Numeric(5, 2), default=0, comment='작업 시간')
    rest_hours = db.Column('rest_hours', db.Numeric(5, 2), default=0, comment='휴식 시간')

    alert_count = db.Column('alert_count', db.Integer, default=0, comment='알림 발생 횟수')
    sos_count = db.Column('sos_count', db.Integer, default=0, comment='SOS 발생 횟수')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "date": self.date.isoformat() if self.date else None,
            "FK_bid": self.FK_bid,
            "avg_hr": float(self.avg_hr) if self.avg_hr else None,
            "min_hr": self.min_hr,
            "max_hr": self.max_hr,
            "avg_spo2": float(self.avg_spo2) if self.avg_spo2 else None,
            "min_spo2": self.min_spo2,
            "total_steps": self.total_steps,
            "total_kcal": float(self.total_kcal) if self.total_kcal else None,
            "work_hours": float(self.work_hours) if self.work_hours else None,
            "rest_hours": float(self.rest_hours) if self.rest_hours else None,
            "alert_count": self.alert_count,
            "sos_count": self.sos_count
        }
        return resultJSON


class Reports(db.Model):
    """분석 리포트 관리"""
    __tablename__ = 'reports'

    id = db.Column('id', db.Integer, primary_key=True)
    title = db.Column('title', db.String(200), nullable=False, comment='리포트 제목')
    type = db.Column('type', db.String(50), nullable=False, comment='리포트 타입 (일간/주간/월간/커스텀)')

    start_date = db.Column('start_date', db.Date, nullable=False, comment='시작일')
    end_date = db.Column('end_date', db.Date, nullable=False, comment='종료일')

    target_type = db.Column('target_type', db.String(20), nullable=False,
                           comment='대상 타입 (INDIVIDUAL/DEPARTMENT/ALL)')
    target_id = db.Column('target_id', db.Integer, comment='대상 ID (근로자 또는 부서)')

    generated_by = db.Column('generated_by', db.Integer, nullable=False, comment='생성자 ID')
    file_path = db.Column('file_path', db.String(500), comment='리포트 파일 경로')

    status = db.Column('status', db.String(20), default='GENERATING',
                      comment='상태 (GENERATING/COMPLETED/FAILED)')

    created_at = db.Column('created_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='생성시간')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "title": self.title,
            "type": self.type,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "generated_by": self.generated_by,
            "file_path": self.file_path,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }
        return resultJSON
