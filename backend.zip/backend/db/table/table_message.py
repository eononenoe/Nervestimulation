# -*- coding: utf-8 -*-
from pytz import timezone
import datetime
from backend.db.database import DBManager
print("module [backend_model.table_message.py] loaded")

db = DBManager.db


class MessageTemplates(db.Model):
    """메시지 템플릿 관리"""
    __tablename__ = 'message_templates'

    id = db.Column('id', db.Integer, primary_key=True)
    name = db.Column('name', db.String(100), nullable=False, comment='템플릿 이름')
    title = db.Column('title', db.String(200), comment='메시지 제목')
    content = db.Column('content', db.Text, nullable=False, comment='메시지 내용')
    type = db.Column('type', db.String(20), default='info', comment='메시지 타입: emergency, warning, info')
    is_active = db.Column('is_active', db.Boolean, default=True, comment='활성화 여부')
    created_at = db.Column('created_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='생성시간')
    updated_at = db.Column('updated_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), onupdate=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='수정시간')
    created_by = db.Column('created_by', db.Integer, comment='생성자 ID')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "name": self.name,
            "title": self.title,
            "content": self.content,
            "type": self.type,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "created_by": self.created_by
        }
        return resultJSON


class MessageRules(db.Model):
    """자동 메시지 발송 규칙"""
    __tablename__ = 'message_rules'

    id = db.Column('id', db.Integer, primary_key=True)
    rule_name = db.Column('rule_name', db.String(100), nullable=False, comment='규칙 이름')
    FK_template_id = db.Column('FK_template_id', db.Integer,
                                db.ForeignKey('message_templates.id', ondelete='CASCADE'),
                                comment='템플릿 ID')
    template = db.relationship('MessageTemplates', backref='rules')

    trigger_type = db.Column('trigger_type', db.String(50), nullable=False,
                            comment='트리거 타입: event, threshold, schedule')
    trigger_condition = db.Column('trigger_condition', db.Text,
                                  comment='트리거 조건 (JSON 형식)')

    target_type = db.Column('target_type', db.String(20), default='user',
                           comment='발송 대상 타입: user, group, all')
    target_value = db.Column('target_value', db.String(100),
                            comment='발송 대상 값')

    recipient_type = db.Column('recipient_type', db.String(20), default='email',
                              comment='수신 방법: email, sms, push, all')

    is_active = db.Column('is_active', db.Boolean, default=True, comment='활성화 여부')
    priority = db.Column('priority', db.Integer, default=0, comment='우선순위 (높을수록 먼저 실행)')

    created_at = db.Column('created_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='생성시간')
    updated_at = db.Column('updated_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), onupdate=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='수정시간')
    created_by = db.Column('created_by', db.Integer, comment='생성자 ID')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "rule_name": self.rule_name,
            "FK_template_id": self.FK_template_id,
            "trigger_type": self.trigger_type,
            "trigger_condition": self.trigger_condition,
            "target_type": self.target_type,
            "target_value": self.target_value,
            "recipient_type": self.recipient_type,
            "is_active": self.is_active,
            "priority": self.priority,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "created_by": self.created_by
        }
        return resultJSON


class MessageHistory(db.Model):
    """메시지 발송 이력"""
    __tablename__ = 'message_history'

    id = db.Column('id', db.Integer, primary_key=True)
    FK_template_id = db.Column('FK_template_id', db.Integer,
                                db.ForeignKey('message_templates.id', ondelete='SET NULL'),
                                nullable=True, comment='템플릿 ID')
    template = db.relationship('MessageTemplates', backref='history')

    FK_rule_id = db.Column('FK_rule_id', db.Integer,
                           db.ForeignKey('message_rules.id', ondelete='SET NULL'),
                           nullable=True, comment='규칙 ID (자동 발송인 경우)')
    rule = db.relationship('MessageRules', backref='history')

    FK_user_id = db.Column('FK_user_id', db.Integer, nullable=True, comment='대상 사용자 ID')
    FK_bid = db.Column('FK_bid', db.Integer, nullable=True, comment='대상 밴드 ID')

    title = db.Column('title', db.String(200), comment='발송된 메시지 제목')
    content = db.Column('content', db.Text, nullable=False, comment='발송된 메시지 내용')

    recipient_type = db.Column('recipient_type', db.String(20), nullable=False,
                              comment='수신 방법: email, sms, push')
    recipient = db.Column('recipient', db.String(100), nullable=False,
                         comment='수신자 (이메일/전화번호/푸시토큰)')

    send_type = db.Column('send_type', db.String(20), default='manual',
                         comment='발송 타입: auto, manual')
    status = db.Column('status', db.String(20), default='pending',
                      comment='발송 상태: pending, sent, failed')
    error_message = db.Column('error_message', db.Text, comment='오류 메시지 (실패 시)')

    sent_at = db.Column('sent_at', db.DateTime, comment='발송 시간')
    created_at = db.Column('created_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='생성시간')
    sent_by = db.Column('sent_by', db.Integer, comment='발송자 ID (수동 발송 시)')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "FK_template_id": self.FK_template_id,
            "FK_rule_id": self.FK_rule_id,
            "FK_user_id": self.FK_user_id,
            "FK_bid": self.FK_bid,
            "title": self.title,
            "content": self.content,
            "recipient_type": self.recipient_type,
            "recipient": self.recipient,
            "send_type": self.send_type,
            "status": self.status,
            "error_message": self.error_message,
            "sent_at": self.sent_at.isoformat() if self.sent_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "sent_by": self.sent_by
        }
        return resultJSON


class AlertRecipients(db.Model):
    """알림 수신자 관리"""
    __tablename__ = 'alert_recipients'

    id = db.Column('id', db.Integer, primary_key=True)
    FK_user_id = db.Column('FK_user_id', db.Integer, nullable=True, comment='사용자 ID')
    FK_group_id = db.Column('FK_group_id', db.Integer, nullable=True, comment='그룹 ID')

    recipient_name = db.Column('recipient_name', db.String(100), nullable=False,
                              comment='수신자 이름')
    email = db.Column('email', db.String(100), comment='이메일')
    phone = db.Column('phone', db.String(30), comment='전화번호')
    push_token = db.Column('push_token', db.String(255), comment='푸시 알림 토큰')

    alert_types = db.Column('alert_types', db.String(200),
                           comment='수신할 알림 타입 (쉼표 구분: emergency,warning,info)')

    is_active = db.Column('is_active', db.Boolean, default=True, comment='활성화 여부')

    created_at = db.Column('created_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='생성시간')
    updated_at = db.Column('updated_at', db.DateTime, default=datetime.datetime.now(
        timezone('Asia/Seoul')), onupdate=datetime.datetime.now(
        timezone('Asia/Seoul')), comment='수정시간')

    def serialize(self):
        resultJSON = {
            "id": self.id,
            "FK_user_id": self.FK_user_id,
            "FK_group_id": self.FK_group_id,
            "recipient_name": self.recipient_name,
            "email": self.email,
            "phone": self.phone,
            "push_token": self.push_token,
            "alert_types": self.alert_types,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
        return resultJSON
