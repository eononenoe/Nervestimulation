print ("module [backend] loaded")
import os
import platform
import logging

from flask_cors import CORS
from flask_sqlalchemy import get_debug_queries
from flask import Flask, render_template, make_response, request
from flask_restless import APIManager
from flask_socketio import SocketIO
from backend.server_configuration.appConfig import *
from flask_mqtt import Mqtt
from flask import send_from_directory

app = Flask(__name__
            , template_folder=os.getcwd()+'/frontend'
            , static_folder=os.getcwd()+'/frontend/assets'
            , static_url_path='/assets')


cors = CORS(app, resources={r"/api/*": {"origins": "*"},
                            r"/admin/api/*": {"origins": "*"},
                            r"/socket.io/*": {
                            "origins": "*",
                            "methods": ["GET", "POST"],
                            "allow_headers": ["token"]
                            }
                        }, max_age=86400)


cur_system = platform.system()
if cur_system == "Windows":
    app.config.from_object(DevelopmentConfig)
else:
    app.config.from_object(ProductionConfig)


from backend.db.database import DBManager
DBManager.init(app)

# login
from flask_login import LoginManager
login_manager = LoginManager()
login_manager.init_app(app)

# api
mqtt = Mqtt()
mqtt.init_app(app)

manager = APIManager(app, flask_sqlalchemy_db=DBManager.db)

# socket init
socketio = SocketIO(app,
                    cors_allowed_origins="*",
                    async_mode='gevent',
                    ping_timeout=10,      # 60초로 증가 (네트워크 지연 대응)
                    ping_interval=5,     # 25초로 증가 (안정적인 연결 유지)
                    # logger=True,          # 로깅 활성화
                    # engineio_logger=True  # Engine.IO 로깅 활성화
                    )

# /admin/api/와 /api/ 모두 지원하도록 before_request 사용
@app.before_request
def handle_admin_api_prefix():
    """
    /admin/api/ 요청을 /api/로 변환
    /admin/socket.io/ 요청을 /socket.io/로 변환
    /devices/list, /devices/register 요청을 직접 처리
    """
    path = request.path

    # 기기 페이지 직접 처리 (Vue Router보다 우선)
    if path == '/devices/list':
        return send_from_directory(os.getcwd()+'/frontend', 'devices_list.html')
    elif path == '/devices/register':
        return send_from_directory(os.getcwd()+'/frontend', 'devices_register.html')

    if path.startswith('/admin/api/'):
        # /admin/api/를 /api/로 변경
        request.environ['PATH_INFO'] = path.replace('/admin/api/', '/api/', 1)
        request.environ['SCRIPT_NAME'] = ''
    elif path.startswith('/admin/socket.io/'):
        # /admin/socket.io/를 /socket.io/로 변경
        request.environ['PATH_INFO'] = path.replace('/admin/socket.io/', '/socket.io/', 1)
        request.environ['SCRIPT_NAME'] = ''

# API와 MQTT를 먼저 로드 (라우트 우선순위를 위해)
from backend.api.api_create import *
from backend.api.mqtt import *

server = db.session.query(Server).first()
if server.start == 0 :
    db.session.query(Server).filter(Server.id == 1).update(dict(start=1))
    db.session.commit()
  
else :
    db.session.query(Server).filter(Server.id == 1).update(dict(start=0))
    db.session.commit()
    mqtt.subscribe('/DT/eHG4/naas/post/sync')
    mqtt.subscribe('/DT/eHG4/naas/post/async')
    mqtt.subscribe('/DT/eHG4/naas/WEATHER/GET')
    mqtt.subscribe('/DT/eHG4/naas/INFO/GET')
    mqtt.subscribe('/DT/eHG4/naas/Status/Band_Events_Data')
    mqtt.subscribe('/DT/eHG4/GPS/Location')

socketio.start_background_task(start_disconnect_checker)

@app.route("/admin/", methods=["GET"])
@app.route("/admin/<path:path>", methods=["GET"])
def admin_index(path=''):
    # 기기 페이지들은 별도 HTML로 렌더링
    if path == 'DevicesList' or path == 'devices/list':
        return send_from_directory(os.getcwd()+'/frontend', 'devices_list.html')
    if path == 'DevicesRegister' or path == 'devices/register':
        return send_from_directory(os.getcwd()+'/frontend', 'devices_register.html')

    # API와 assets는 before_request에서 처리됨
    if path.startswith('api/') or path.startswith('assets/'):
        # 이 경로들은 다른 핸들러에서 처리
        from flask import abort
        abort(404)

    # 모든 /admin/ 경로는 SPA의 index.html로 처리
    resp = make_response(render_template("index.html"))
    return resp