# -*- coding: utf-8 -*-
print ("module [server_configuration] loaded")

__all__ = [
    'CommonConfig'
]